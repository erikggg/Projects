﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAHAssignment2
{
    class MainProgram
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();

            menu.Start();
        }

    }
}
